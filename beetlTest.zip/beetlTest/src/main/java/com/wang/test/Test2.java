package com.wang.test;

public class Test2 {

    public static void main(String[] args) {
        String a = null;

        if(null==a){
            System.out.println(a);
        }
    }
}
