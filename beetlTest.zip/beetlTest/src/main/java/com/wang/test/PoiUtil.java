package com.wang.test;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PoiUtil {

    public static List<Object> ExcelReadDealUtils(String address) {

        File file = new File(address);
        try {
            HSSFWorkbook wb = new HSSFWorkbook(new FileInputStream(file));
            HSSFSheet sheet = wb.getSheetAt(0);

            List<Object> batchDatas = new ArrayList<>();
            int startRowIndex = 0;
            int endRowIndex = sheet.getLastRowNum();
            if(startRowIndex > endRowIndex){
                throw new RuntimeException("错误提示：开始行不能大于结束行!");
            }
            // 获取sheet总行数
            int lastRowNum = sheet.getLastRowNum();
            if(startRowIndex > lastRowNum || endRowIndex > lastRowNum){
                throw new RuntimeException("错误提示：开始行或结束行不能超过sheet最大行数!");
            }
            for (int i = startRowIndex; i <= endRowIndex; i++) {
                Row row = sheet.getRow(i);
                batchDatas.add(getRowDataToList(row));// 此处不需要验证row是否为空,在底层getRowData已验证
            }
            return batchDatas;
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static List<Object> getRowDataToList(Row row) {
        List<Object> rowData = new ArrayList<Object>();
        if (isExistRow(row)) {
            short countCellNum = row.getLastCellNum();
            for (int i = 0; i < countCellNum; i++) {
                Cell cell = row.getCell(i);
                if (isExistCell(cell)) {
                    rowData.add(getCellValue(cell));
                }
            }
        }
        return rowData;
    }

    protected static boolean isExistCell(Cell cell) {
        return isExist(cell);
    }

    protected static boolean isExistRow(Row row) {
        return isExist(row);
    }

    protected static boolean isExist(Object object) {
        if (object == null) {
            return false;
        }
        return true;
    }
    protected static Object getCellValue(Cell cell) {
        Object obj = null;
        if(cell == null){
            return "";
        }
        int cellType = cell.getCellType();
        switch (cellType) {
            case Cell.CELL_TYPE_BOOLEAN:
                obj = cell.getBooleanCellValue();
                break;
            case Cell.CELL_TYPE_FORMULA:
                obj = cell.getCellFormula();
                break;
            case Cell.CELL_TYPE_NUMERIC:
                obj = cell.getNumericCellValue();
                break;
            case Cell.CELL_TYPE_STRING:
                obj = cell.getStringCellValue();
                break;
            case Cell.CELL_TYPE_BLANK:
                obj = "";
                break;
            default:
                obj = cell.getRichStringCellValue();
                throw new RuntimeException("单元格为未知类型!");
        }
        return obj;
    }

}
