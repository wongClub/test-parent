package com.wang.test;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class Test1 {

    public static void main(String[] args) throws ParseException {
        /*long l = 1533188018;
        long l1 = System.currentTimeMillis();
        String date = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(l * 1000));
        System.out.println(date);
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������Ҫת�ɺ��ʱ��ĸ�ʽ
        String sd = sdf.format(new Date(l));   // ʱ���ת����ʱ��*/

        /*String res;
        String s = "20180601121221";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        long aLong = Long.parseLong(s);
//        long lt = new Long(s);
        Date date = new Date(aLong);
        res = simpleDateFormat.format(date);
        System.out.println(res);*/

        /*String s = "2018-06-01 12:12:21";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = simpleDateFormat.parse(s);
        long ts = date.getTime();
        Long res = Long.valueOf(String.valueOf(ts));
        System.out.println(res/1000);*/

        String a = "20.3/25.3/26.3";
        BigDecimal bigDecimal = new BigDecimal("20.3");
        char[] chars = a.toCharArray();
        System.out.println(bigDecimal);
    }
}
