package com.wang.test;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.abel533.echarts.AxisPointer;
import com.github.abel533.echarts.Option;
import com.github.abel533.echarts.axis.CategoryAxis;
import com.github.abel533.echarts.axis.ValueAxis;
import com.github.abel533.echarts.code.Orient;
import com.github.abel533.echarts.code.Tool;
import com.github.abel533.echarts.json.GsonOption;
import com.github.abel533.echarts.series.Bar;
import com.github.abel533.echarts.series.Line;
import com.github.abel533.echarts.series.Pie;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class JsonUtil {

    public static String jsonBar(String address) {
        //String address = "C:\\Users\\domainclient\\Desktop\\mapping_region.stat.json";
        InputStreamReader read = null;
        try{
            File file = new File(address);
            if (file.isFile() && file.exists()) { //判断文件是否存在
                read = new InputStreamReader(
                        new FileInputStream(file), "utf8");//考虑到编码格式
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;
                StringBuilder sbBuffer = new StringBuilder();
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    System.out.println(lineTxt);
                    sbBuffer.append(lineTxt + "\n");
                }

                JSONObject json = JSONObject.parseObject(sbBuffer.toString());
                JSONArray title = json.getJSONArray("title");
                JSONArray data = json.getJSONArray("data");
                JSONArray label = json.getJSONArray("label");
                //获取x轴信息
                String o = title.toString();
                //表格x坐标下的文字
                String[] xname = o.substring(o.indexOf(",")+1,o.indexOf("]")).replace("]","").replace("\"","").split(",");
                //创建echarts所用的数据
                Option option = new GsonOption();
                //设置标题
                option.title().text((String) label.get(0)).x("center");
                //设置显示的样式
                option.tooltip().show(true).formatter("{a}</br>{b}:{c}");
                //设置y轴,,,,不给定具体值,,,,,自动调整
                ValueAxis valueAxis = new ValueAxis();
                option.yAxis(valueAxis.name((String) label.get(2)));

                //循环数据
                for (int i = 0; i<data.size(); i++){
                    //获取数据
                    String m1 = data.get(i).toString();
                    //去除数据的前一部分
                    String[] split = m1.substring(m1.indexOf(",") + 1, m1.indexOf("]")).replace("]", "").split(",");
                    //获取该数据的名称
                    String s1 = m1.substring(m1.indexOf("[") + 1, m1.indexOf(",")).replace("\"","");
                    Bar bar = new Bar(s1);
                    //3.设置图例  可选
                    //设置图例,居中底部显示，显示边框
                    option.legend().data(s1).x("right").orient(Orient.vertical);
                    for(int j=0; j<split.length; j++){
                        Map<String, Object> map = new HashMap<>();
                        map.put("value",split[j].replace("\"",""));
                        map.put("name",xname[j]);
                        bar.data(map);
                    }
                    option.series(bar.stack("总量"));
                }
                /*//拼接数据
                //第一条数据
                String m1 = data.get(0).toString();
                String message1 = m1.substring(m1.indexOf(",") + 1, m1.indexOf("]")).replace("]", "");
                String[] split = message1.split(",");
                String s1 = m1.substring(m1.indexOf("[") + 1, m1.indexOf(",")).replace("\"","");
                Bar bar = new Bar(s1);
                //3.设置图例  可选
                //设置图例,居中底部显示，显示边框
                option.legend(s1);
                for(int j=0; j<split.length; j++){
                    Map<String, Object> map = new HashMap<>();
                    map.put("value",split[j].replace("\"",""));
                    map.put("name",xname[j]);
                    bar.data(map);
                }

                //柱状数据
                //第二条数据
                String m2 = data.get(1).toString();
                String[] split2 = m2.substring(m2.indexOf(",") + 1, m2.indexOf("]")).replace("]", "").split(",");
                String s2 = m2.substring(m2.indexOf("[") + 1, m2.indexOf(",")).replace("\"","");
                Bar bar2 = new Bar(s2);
                //3.设置图例  可选
                //设置图例,居中底部显示，显示边框
                option.legend(s2);
                for(int j=0; j<split2.length; j++){
                    Map<String, Object> map = new HashMap<>();
                    map.put("value",split2[j].replace("\"",""));
                    map.put("name",xname[j]);
                    bar2.data(map);
                }

                //柱状数据
                //第三条数据
                String m3 = data.get(2).toString();
                String[] split3 = m3.substring(m3.indexOf(",") + 1, m3.indexOf("]")).replace("]", "").split(",");
                String s3 = m3.substring(m3.indexOf("[") + 1, m3.indexOf(",")).replace("\"","");
                Bar bar3 = new Bar(s3);
                //3.设置图例  可选
                //设置图例,居中底部显示，显示边框
                option.legend(s3);
                for(int j=0; j<split3.length; j++){
                    Map<String, Object> map = new HashMap<>();
                    map.put("value",split3[j].replace("\"",""));
                    map.put("name",xname[j]);
                    bar3.data(map);
                }*/

                //X轴--
                //6.设置x轴数据
                CategoryAxis categoryAxis = new CategoryAxis();
                categoryAxis.data(xname).axisLabel().interval(0).rotate(40);//axisLabel:{interval: 0}  rotate--倾斜角度
                option.xAxis(categoryAxis.name((String) label.get(1)));

                option.grid().left("15%").right("40%");

                //设置数据
                /*option.series(bar.stack("总量"));
                option.series(bar2.stack("总量"));
                option.series(bar3.stack("总量"));*/
                String result = option.toString();


                return result;

            } else {
                return "找不到指定的文件";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "读取文件内容出错";
        }finally {
            try {
                read.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String jsonPie(String address) {
        //String address = "C:\\Users\\domainclient\\Desktop\\mapping_region.stat.json";
        InputStreamReader read = null;
        try{
            File file = new File(address);
            if (file.isFile() && file.exists()) { //判断文件是否存在
                read = new InputStreamReader(
                        new FileInputStream(file), "utf8");//考虑到编码格式
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;
                StringBuilder sbBuffer = new StringBuilder();
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    System.out.println(lineTxt);
                    sbBuffer.append(lineTxt + "\n");
                }

                JSONObject json = JSONObject.parseObject(sbBuffer.toString());
                JSONArray title = json.getJSONArray("title");
                JSONArray data = json.getJSONArray("data");
                JSONArray label = json.getJSONArray("label");

                //获取x轴信息
                String o = title.toString();
                //表格x坐标下的文字
                String[] xname = o.substring(o.indexOf(",")+1,o.indexOf("]")).replace("]","").replace("\"","").split(",");
                //创建echarts所用的数据
                Option option = new GsonOption();
                //设置标题
                option.title().text(String.valueOf(label.get(0))).x("center");
                //设置显示的样式
                //设置工具栏 展示  能标记
                option.toolbox().show(true).feature(Tool.mark);
                option.tooltip().show(true).formatter("{a}</br>{b}:{c}%");

                //拼接数据
                //第一条数据
                String m1 = data.get(0).toString();
                String message1 = m1.substring(m1.indexOf(",") + 1, m1.indexOf("]")).replace("]", "");
                String[] split = message1.split(",");
                String s1 = m1.substring(m1.indexOf("[") + 1, m1.indexOf(",")).replace("\"","");
                Pie pie = new Pie();//创建饼图对象
                //3.设置图例  可选
                //设置图例,居中底部显示，显示边框
                option.legend().data(title).x("left").orient(Orient.vertical);
                //设置饼图的标题 半径、位置
                pie.name(s1).radius("55%").center("50%","50%");
                for(int j=0; j<split.length; j++){
                    Map<String, Object> map = new HashMap<>();
                    map.put("value",split[j].replace("\"","").replace("%",""));
                    map.put("name",xname[j]);
                    pie.data(map);
                }

                //option.grid().left("15%").right("40%");

                //设置数据
                option.series(pie);
                String result = option.toString();


                return result;

            } else {
                return "找不到指定的文件";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "读取文件内容出错";
        }finally {
            try {
                read.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String jsonLine(String address) {
        //String address = "C:\\Users\\domainclient\\Desktop\\mapping_region.stat.json";
        InputStreamReader read = null;
        try{
            File file = new File(address);
            if (file.isFile() && file.exists()) { //判断文件是否存在
                read = new InputStreamReader(
                        new FileInputStream(file), "utf8");//考虑到编码格式
                BufferedReader bufferedReader = new BufferedReader(read);
                String lineTxt = null;
                StringBuilder sbBuffer = new StringBuilder();
                while ((lineTxt = bufferedReader.readLine()) != null) {
                    sbBuffer.append(lineTxt + "\n");
                }

                JSONObject json = JSONObject.parseObject(sbBuffer.toString());
                JSONArray title = json.getJSONArray("title");
                JSONArray data = json.getJSONArray("data");

                //获取x轴信息
                String o = title.toString();
                //表格x坐标下的文字
                String[] xname = o.substring(o.indexOf(",")+1,o.indexOf("]")).replace("]","").replace("\"","").split(",");
                //创建echarts所用的数据
                Option option = new GsonOption();
                //设置标题
                option.title().text("json-bar").x("left");
                option.tooltip().show(true);
                //option.toolbox().show(true).feature(Tool.magicType,Tool.dataZoom);
                //设置显示的样式
                option.tooltip().show(true).formatter("{a}</br>{b}:{c}");
                //设置y轴,,,,不给定具体值,,,,,自动调整
                ValueAxis valueAxis = new ValueAxis();
                option.yAxis(valueAxis);

                //x数据
                CategoryAxis categoryAxis = new CategoryAxis();
                categoryAxis.data(xname);
                option.xAxis(categoryAxis);
                String[] legend = new String[data.size()];
                for(int i = 0; i<data.size(); i++){

                    Line line = new Line();
                    String d = String.valueOf(data.get(i));
                    String[] split = d.substring(d.indexOf(",") + 1, d.indexOf("]")).replace("]", "").split(",");
                    String replace = d.substring(d.indexOf("[") + 1, d.indexOf(",")).replace("\"", "");
                    line.name(replace);
                    legend[i] = replace;
                    for(int j = 0; j<xname.length; j++){
                        line.data(split[j].replace("\"",""));
                    }

                    option.series(line);
                }
                option.legend().data(legend).x("center");
                option.grid().left("15%").right("30%");
                return option.toString();




            } else {
                return "找不到指定的文件";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "读取文件内容出错";
        }finally {
            try {
                read.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static String jsonBoxplot(String address){

        Option option = new GsonOption();
        option.title().text("Michelson-Morley Experiment").x("center");
        option.tooltip().show(true);
        option.tooltip().axisPointer();

        return "";
    }
}
