package com.wang.test;

import com.jfinal.core.Controller;

import java.util.List;

public class HomeController  extends Controller {

    public void index(){
        render("/index.jsp");
    }

    public void findMesage(){

        //文件的地址
        String address = "C:\\Users\\domainclient\\Desktop\\test.xls";
        List<Object> objects = PoiUtil.ExcelReadDealUtils(address);
        renderJson(objects);
    }

}
