package com.wang.test;

import com.github.abel533.echarts.Label;
import com.github.abel533.echarts.Option;
import com.github.abel533.echarts.axis.AxisLine;
import com.github.abel533.echarts.axis.CategoryAxis;
import com.github.abel533.echarts.axis.SplitLine;
import com.github.abel533.echarts.axis.ValueAxis;
import com.github.abel533.echarts.code.Orient;
import com.github.abel533.echarts.code.Position;
import com.github.abel533.echarts.code.Tool;
import com.github.abel533.echarts.code.Trigger;
import com.github.abel533.echarts.code.X;
import com.github.abel533.echarts.code.Y;
import com.github.abel533.echarts.json.GsonOption;
import com.github.abel533.echarts.series.Bar;
import com.github.abel533.echarts.series.Line;
import com.github.abel533.echarts.series.Pie;
import com.github.abel533.echarts.style.LineStyle;
import com.jfinal.core.Controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EChartsController extends Controller {

    public List<AccessData> getWeekData() {
        List<AccessData> list = new ArrayList<AccessData>(7);
        list.add(new AccessData("09-16", 4));
        list.add(new AccessData("09-17", 7));
        list.add(new AccessData("09-18", 14));
        list.add(new AccessData("09-19", 304));
        list.add(new AccessData("09-20", 66));
        list.add(new AccessData("09-21", 16));
        list.add(new AccessData("09-22", 205));
        Map<String, Integer> map = new HashMap<>();
        map.put("09-16", 4);
        map.put("09-17", 7);
        map.put("09-18", 14);
        map.put("09-19", 304);
        map.put("09-20", 66);
        map.put("09-21", 16);
        map.put("09-22", 205);
        List<Map<String, Integer>> arrayList = new ArrayList<>();
        return list;
    }
    //数据对象
    class AccessData {
        //日期
        private String date;
        //访问量
        private Integer nums;

        AccessData(String date, Integer nums) {
            this.date = date;
            this.nums = nums;
        }

        public String getDate() {
            return date;
        }

        public Integer getNums() {
            return nums;
        }
    }


    /*public void lineTest() {
        //获取数据
        List<Map<String, Integer>> datas = getWeekData();

        Option option = new GsonOption();
        //设置标题
        option.title().text("柱状图测试").x("left");
        option.legend().data("访问量").x(X.center).y(Y.bottom).borderWidth(1);
        //设置y轴为值轴，并且不显示y轴，最大值设置400，最小值-100（OSC为什么要有-100呢？）
        option.yAxis(new ValueAxis().name("IP")
                .axisLine(new AxisLine().show(true).lineStyle(new LineStyle().width(0)))
                .max(400).min(-100));
        //创建类目轴，并且不显示竖着的分割线，onZero=false
        CategoryAxis categoryAxis = new CategoryAxis()
                .splitLine(new SplitLine().show(false))
                .axisLine(new AxisLine().onZero(false));

        //不显示表格边框，就是围着图标的方框
        option.grid().borderWidth(0);

        //创建Line数据
        Line line = new Line("访问量").smooth(true);

        //根据获取的数据赋值
        for (AccessData data : datas) {
            //增加类目，值为日期
            categoryAxis.data(data.getDate());

            //日期对应的数据
            line.data(data.getNums());
        }

        //设置x轴为类目轴
        option.xAxis(categoryAxis);

        //设置数据
        option.series(line);

        String result = option.toString();

        renderJson(result);
    }*/

    public void barTest() {
        //获取数据
        List<AccessData> datas = getWeekData();

        String address = "C:\\Users\\domainclient\\Desktop\\test.xls";
        List<Object> objects = PoiUtil.ExcelReadDealUtils(address);
        String o = objects.get(0).toString();
        //表格x坐标下的文字
        String s = o.substring(o.indexOf(",")+1,o.indexOf("]")).replace("]","");
        //x坐标
        String[] xname = s.split(",");
        Option option = new GsonOption();

        //2.设置标题  可选
        option.title().text("bar").x("left");//将标题传入即可 并且支持链式调用 设置显示位置 居左
        //4.设置工具栏  可选
        option.toolbox().show(true).feature(Tool.mark,
                Tool.magicType); //设置可标记
        //5.设置显示工具
        option.tooltip().show(true).
                formatter("{a}</br>{b}:{c}");//设置显示的格式 当鼠标放到柱状图上时的显示格式

        //7.设置y轴 这里不给指定数据  自动调整
        ValueAxis valueAxis = new ValueAxis();
        option.yAxis(valueAxis);

        //柱状数据
        //第一条数据
        String m1 = objects.get(1).toString();
        String message1 = m1.substring(m1.indexOf(",") + 1, m1.indexOf("]")).replace("]", "");
        String[] split = message1.split(",");
        String s1 = m1.substring(m1.indexOf("[") + 1, m1.indexOf(","));
        Bar bar = new Bar(s1);
        //3.设置图例  可选
        //设置图例,居中底部显示，显示边框
        option.legend(s1);
        barFor(xname, split, bar);

        //柱状数据
        //第二条数据
        String m2 = objects.get(2).toString();
        String[] split2 = m2.substring(m2.indexOf(",") + 1, m2.indexOf("]")).replace("]", "").split(",");
        String s2 = m2.substring(m2.indexOf("[") + 1, m2.indexOf(","));
        Bar bar2 = new Bar(s2);
        //3.设置图例  可选
        //设置图例,居中底部显示，显示边框
        option.legend(s2);
        barFor(xname, split2, bar2);

        //柱状数据
        //第三条数据
        String m3 = objects.get(3).toString();
        String[] split3 = m3.substring(m3.indexOf(",") + 1, m3.indexOf("]")).replace("]", "").split(",");
        String s3 = m3.substring(m3.indexOf("[") + 1, m3.indexOf(","));
        Bar bar3 = new Bar(s3);
        //3.设置图例  可选
        //设置图例,居中底部显示，显示边框
        option.legend(s3);
        barFor(xname, split3, bar3);

        //X轴--
        //6.设置x轴数据
        CategoryAxis categoryAxis = new CategoryAxis();
        categoryAxis.data(xname).axisLabel().interval(0).rotate(40);//axisLabel:{interval: 0}  rotate--倾斜角度
        option.xAxis(categoryAxis);


        //设置数据
        option.series(bar.stack("总量"));
        option.series(bar2.stack("总量"));
        option.series(bar3.stack("总量"));
        String result = option.toString();

        renderJson(result);
    }

    private void barFor(String[] xname, String[] split3, Bar bar3) {
        for(int j=0; j<split3.length; j++){
            Map<String, Object> map = new HashMap<>();
            map.put("value",split3[j]);
            map.put("name",xname[j]);
            bar3.data(map);
        }
    }

    public void pieTest(){

        //需要的数据
        String title = "R1GVM12";
        String[] searchs = {"Exon","Intron","Intergenic"};
        String[] datas = {"44","5.66","50.35"};

        //创建option对象
        Option option = new GsonOption();

        //设置标题  二级标题  标题位置
        option.title().text(title).subtext("二级标题").x("center");

        //设置工具栏 展示  能标记
        option.toolbox().show(true).feature(Tool.mark);

        //设置显示工具格式
        option.tooltip().show(true).formatter("{a}</br>{b}：{c}%");

        //设置图例  图例位置  图例对齐方式 竖列对齐
        option.legend().data(searchs).x("left").orient(Orient.vertical);

        //填充数据
        Pie pie = new Pie();//创建饼图对象

        //设置饼图的标题 半径、位置
        pie.name(title).radius("55%").center("50%","50%");

        //填充数据
        for(int i = 0; i < searchs.length; i++){
            Map<String,Object> map = new HashMap<>();
            map.put("value",datas[i].replace("%",""));//填充饼图数据
            map.put("name",searchs[i]);//填充饼图数据对应的搜索引擎
            pie.data(map);
        }
        option.series(pie); //设置数据

        renderJson(option.toString());
    }


    public void jsonBar(){

        String s = JsonUtil.jsonPie("C:\\Users\\domainclient\\Desktop\\Js_plot\\C5_mapping_region_pie.json");
        renderJson(s);

    }

}
