package com.wang.beetl;

public class Template {

    public static String abc="hello,${name},${age}";
}
