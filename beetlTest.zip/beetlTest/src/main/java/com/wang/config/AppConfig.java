package com.wang.config;


import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.wang.test.EChartsController;
import com.wang.test.HomeController;
import org.beetl.ext.jfinal.BeetlRenderFactory;

public class AppConfig extends JFinalConfig {

    @Override
    public void configConstant(Constants constants) {
        constants.setMainRenderFactory(new BeetlRenderFactory());
    }

    @Override
    public void configRoute(Routes routes) {
        routes.add("/", HomeController.class)
              .add("/echarts",EChartsController.class);

    }

    @Override
    public void configPlugin(Plugins plugins) {
    }

    @Override
    public void configInterceptor(Interceptors interceptors) {
    }

    @Override
    public void configHandler(Handlers handlers) {

    }

}
