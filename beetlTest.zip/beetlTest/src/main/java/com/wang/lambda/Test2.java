package com.wang.lambda;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static java.util.Comparator.comparing;

public class Test2 {

    public static void main(String[] args) {
        //new Thread(()->{System.out.print("Hello Word!");}).start();

        /*List<String> list= Arrays.asList("java","php","c");
        list.forEach(x->System.out.print(x+" "));
        list.forEach(System.out::print);*/

        List<Double> cost = Arrays.asList(40.0, 20.0,30.0);
        cost.stream().map(x -> x + x*0.05).forEach(x -> System.out.println(x));
        System.out.println("---------*******---------");
        double allCost = cost.stream().map(x -> x+x*0.05).reduce((sum,x) -> sum + x).get();
        System.out.println(allCost);
        System.out.println("---------*******---------");
        cost.stream().map(x -> x>25.0).forEach(x -> System.out.println(x));
        List<Double> filteredCost = cost.stream().filter(x -> x > 25.0).collect(Collectors.toList());
        filteredCost.forEach(x -> System.out.println(x));

    }

    public void filterTest(List<String> languages, Predicate<String> condition) {
        languages.stream().filter(x -> condition.test(x)).forEach(x -> System.out.println(x + " "));
    }

    @Test
    public void main1() {
        List<String> languages = Arrays.asList("Java","Python","scala","Shell","R");
        System.out.println("Language starts with J: ");
        filterTest(languages,x -> x.startsWith("J"));
        System.out.println("\nLanguage ends with a: ");
        filterTest(languages,x -> x.endsWith("a"));
        System.out.println("\nAll languages: ");
        filterTest(languages,x -> true);
        System.out.println("\nNo languages: ");
        filterTest(languages,x -> false);
        System.out.println("\nLanguage length bigger three: ");
        filterTest(languages,x -> x.length() > 4);
    }

    @Test
    public void test3(){
        User user = new User();
        user.setName("zhangsan");
        user.setName("lisi");
        Comparator<User> comparing = Comparator.comparing(User::getName);
        System.out.print(comparing);

    }
}
