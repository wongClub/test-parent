document.write('<script src="core/utHelper.js"><\/script>');

// Specs ...
document.write('<script src="spec/core/util.js"><\/script>');
